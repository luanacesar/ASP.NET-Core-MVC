﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyRecipes.Models
{
    public class EFRecipeRepository : IRecipeRepository
    {
        private ApplicationDbContext context;

        public EFRecipeRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IQueryable<Recipe> FoodRec => context.FoodRec;


        public void SaveRecipe(Recipe recipe)
        {
            if(recipe.RecipeId == 0)
            {
                context.FoodRec.Add(recipe);
            }
            else
            {
                Recipe recipeEntry = context.FoodRec
                    .FirstOrDefault(r => r.RecipeId == recipe.RecipeId);

                if(recipeEntry != null)
                {
                    recipeEntry.RecipeName = recipe.RecipeName;
                    recipeEntry.Ingredients = recipe.Ingredients;
                    recipeEntry.ChefId = recipe.ChefId;
                    recipeEntry.RecipePrepTime = recipe.RecipePrepTime;
                    recipeEntry.Description = recipe.Description;
                }

            }
            context.SaveChanges();
        }

        public Recipe DeleteRecipe(int recipeId)
        {
            Recipe recipeEntry = context.FoodRec
                  .FirstOrDefault(r => r.RecipeId == recipeId);
            if (recipeEntry != null)
            {

                context.FoodRec.Remove(recipeEntry);
                context.SaveChanges();
            }
            return recipeEntry;
        }
    }
}


