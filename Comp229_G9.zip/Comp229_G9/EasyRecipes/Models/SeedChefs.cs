﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyRecipes.Models
{
    public static class SeedChefs
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices.GetRequiredService<ApplicationDbContext>();

            context.Database.Migrate();

            if (!context.Chefs.Any())
            {
                context.Chefs.AddRange(
                    new Chef
                    {
                        ChefName = "Andrea",
                        Specialty = "Ecuadorian",
                        IsEmployed = true,
                        YearsOfExperience = 2
                    },
                    new Chef
                    {
                        ChefName = "Luana",
                        Specialty = "Brazilian",
                        IsEmployed = false,
                        YearsOfExperience = 1
                    },
                    new Chef
                    {
                        ChefName = "Raphael",
                        Specialty = "Chinese",
                        IsEmployed = true,
                        YearsOfExperience = 3
                    }
                    );

                context.SaveChanges();
            }
        }
    }
}
