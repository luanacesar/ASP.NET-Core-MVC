﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace EasyRecipes.Models
{
    public static class SeedData
    {
        public static void EnsurePopulared(IApplicationBuilder app)
        {
            ApplicationDbContext cont = app.ApplicationServices.GetRequiredService<ApplicationDbContext>();
            cont.Database.Migrate();

            if (!cont.FoodRec.Any())
            {

                cont.FoodRec.AddRange(

                    new Recipe {
                       
                        RecipeName = "Brigadeiro",
                        Ingredients = "1) 1 (14oz) can sweet condensed milk \r\n" +
                         "2) 4 Tbsp cocoa powder,\r\n" + "3) Sifted \r\n" + "4) 2 Tbsp butter \r\n" +
                        "5) plus more for rolling balls \r\n" + "6) A pinch of salt \r\n" + "7) Good quality chocolate sprinkles(or any other type of sprinkles you like)\r\n",
                        ChefId = 1,
                        Category =3,
                        RecipePrepTime = "45 min",
                        Description = "In a small sauce pan mix the sweet condensed milk, the cocoa powder, the salt and the butter.\r\n" +
                        "Bring the sauce pan to the stove and heat it over medium - low heat." + "Cook it,mixing constantly(this is important, otherwise it will burn!) until it thickens. \r\n" +
                        "A way to know is to run your wooden spoon(or spatula) in the middle of the mixture.If it takes a while for the mixture to move, then your brigadeiro is ready!\r\n" +
                      " Reserve, letting it cool to room temperature." + "In a plate or bowl, spread your sprinkles.\r\n" +
                       "Once the brigadeiro is cool, grease your hands with butter and roll the brigadeiros into little balls. \r\n" +
                       "(In Brazil we usually use half a tablespoon as measurement, but you can make your balls as big or small as you'd like!) \r\n" +
                       "Roll the brigadeiro balls into the sprinkles and place them in paper / foil candy cups."
                                },
                       new Recipe
                       {
                           
                           RecipeName = "Coxinha",
                           Ingredients = "1) tablespoon olive oil \r\n" + " 2) 4 cloves garlic,minced \r\n" + " 3) 1 white onion,diced \r\n" + "4) 2 cups chicken(250 g), cooked,shredded \r\n" +
                            "5) ½ teaspoon paprika, or cayenne pepper salt, to taste \r\n" + "6) 4 oz cream cheese(110 g) \r\n" + "7) 3 tablespoons fresh parsley, chopped \r\n" + "DOUGH: \r\n" +
                                "8) 1 tablespoon unsalted butter \r\n" + "9) 2 cups whole milk(470 mL)\r\n" + "10) ¼ cup chicken broth(60 mL) \r\n" + "11) 2 cups all - purpose flour(250 g) egg \r\n" +
                                "12) 2 cups panko breadcrumbs(100 g) \r\n" +  "13) Oil, for frying." ,
                           ChefId = 2,
                           Category = 1,
                           RecipePrepTime = "1h 50 min",
                           Description = "1)  In a medium pot, heat olive oil, then sauté garlic and onions until soft and brown. \r\n" +
                           "2) Add shredded chicken, salt, and paprika (or cayenne pepper). Stir to incorporate.\r\n " +
                           "3) Transfer mixture into a bowl, add cream cheese and parsley.Mix well.\r\n" +
                           "4) In the same pot, add butter, chicken broth, and milk.Bring to a boil.Stir in flour until dough is formed. \r\n" +
                            "5) Transfer dough to a flat surface.Knead the dough while it is warm, but not hot. \r\n" +
                            "6) Pinch a piece of dough, about the size of a large egg, and roll into a ball. \r\n" +
                            "7) Using your hands, flatten the dough and spoon filling into the center.Wrap the dough into a pear shape and make sure there aren’t any holes.\r\n" +
                            "8) While heating a pot of oil to 350˚F / 180˚C, dredge the dough in egg and panko, then deep-fry till golden brown and cooked through.\r\n " +
                            "9) Drain on a towel, or wire rack and serve immediately.Enjoy!"
                       },
                        new Recipe
                        {
                        
                            RecipeName = "Chicken Pie",
                            Ingredients = "1) 2 tablespoons olive oil2 medium onions, finely chopped \r\n" + 
                            "2) 2 garlic cloves, minced \r\n" + 
                            "3) 2 tomatoes,chopped" + 
                            "4) 2 pounds chicken breast,cooked and shredded \r\n" +
                            "5) 1 / 2 cup chopped green olives \r\n" +
                            "6) 1 cup corn(optional) \r\n" +
                            "7) 1 cup green peas(optional) \r\n" +
                            "8) 1 cup hearts of palm,  chopped(optional)\r\n" +
                            "9) 1 cup tomato sauce\r\n" +
                            "10) A couple dashes of hot sauce \r\n" +
                            "11) 2 cups chicken broth \r\n" +
                            "12) 1 tablespoon flour dissolved in 1 / 3 cup milk \r\n" +
                            "1 / 2 cup chopped parsley \r\n" +
                             " Salt and pepper to taste \r\n",
                            ChefId = 3,
                            Category = 4,
                            RecipePrepTime = "1h 10 min",
                            Description = "HARD TO MAKE"
                        },
                             new Recipe
                             {

                                 RecipeName = "Lemon Cake",
                                 Ingredients = "1) 3 cups (345g) sifted all-purpose flour* (spoon & leveled)\r\n" +
                                    "2) 2 and 1 / 2 teaspoons baking powder\r\n" +
                                    "3) 1 / 2 teaspoon baking soda\r\n" +
                                    "4) 1 / 2 teaspoon salt\r\n" +
                                    "5) 1 cup(230g) unsalted butter,\r\n" +
                                    "6) 1 and 3 / 4 cups(350g) granulated sugar\r\n" +
                                    "7) 3 large eggs, at room temperature\r\n" +
                                    "8) 2 teaspoons pure vanilla extract\r\n" +
                                    "9) 1 cup(240ml) buttermilk,at room temperature\r\n" +
                                    "10) 1 heaping Tablespoon lemon zest(about 2 lemons)\r\n" +
                                    "11) 1 / 3 cup(80ml) fresh lemon juice(about 2 lemons)\r\n",
                                 ChefId = 1,
                                 Category = 3,
                                 RecipePrepTime = "1 HOUR",
                                 Description = "Using a handheld or stand mixer fitted with a paddle or whisk attachment,\r\n" +
                                 " beat the butter and sugar together on high speed until smooth and creamy, about 3 minutes.\r\n " +
                                 "Scrape down the sides and up the bottom of the bowl with a rubber spatula as needed.\r\n " +
                                 "Beat in the eggs and vanilla extract on high speed until combined, about 2 minutes. \r\n" +
                                 "Scrape down the sides and up the bottom of the bowl as needed. With the mixer on low speed, \r\n" +
                                 "add the dry ingredients just until combined. With the mixer still running on low, add the buttermilk,\r\n " +
                                 "lemon zest, and lemon juice and mix just until combined. You may need to whisk it all by hand to make sure there are no lumps at the bottom of the bowl. \r\n" +
                                 "The batter will be a little thick. "
                             },
                               new Recipe
                               {
                                 
                                   RecipeName = "juice",
                                   Ingredients = "4 fruit (2-3/8 dia)s orange",
                                   ChefId = 2,
                                   Category = 4,
                                   RecipePrepTime = "10 min",
                                   Description = "Lightly smack each orange on the counter. Cut each one in half. Squeeze into a glass. You may also use a citrus reamer to do this. \r\n" +
                                   "If you want less pulp, use a hand juicer with a strainer."
                               },
                                 new Recipe
                                 {
                                  
                                     RecipeName = "Tea",
                                     Ingredients = "green tea",
                                     ChefId = 2,
                                     Category = 4,
                                     RecipePrepTime = "10 min",
                                     Description = "1. Citrus Mint Iced Tea \r\n" + " Toss some mint leaves,orange slices and green tea bags into a boiling teapot for a delicious homemade tea.\r\n" +
                                     "Serve over ice and garnish the glasses with orange or lime slices\r\n." + "2.Green Ginger Mint Tea\r\n" + "Green tea with spearmint is a popular Moroccan digestive.\r\n" +
                                     "Green tea lives, such as gunpowder leaves, are rolled into small balls that unfurl in hot water to release a slightly bitter, smoky infusion.\r\n" + "This refreshing brew is also good iced.Sweeten with honey, if desired.\r\n" +
                                     "3.Mango Calendula Ceylon Tea When sweetened with mango and ginger, delicate teas like green gunpowder make for refreshing afternoon drinks or light, fruity iced teas.\r\n" +
                                     "Add sugar after steeping if you wish to accentuate the fruity flavour.",
                                 }
                    );
                cont.SaveChanges();
            }
        }

    }
}
