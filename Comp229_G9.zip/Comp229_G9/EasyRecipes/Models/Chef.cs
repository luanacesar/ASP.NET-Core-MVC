﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyRecipes.Models
{
    public class Chef
    {
        public int ChefId { get; set; }
        public string ChefName { get; set; }
        public string Specialty { get; set; }
        public double YearsOfExperience { get; set; }
        public bool IsEmployed { get; set; }
    }
}
