﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace EasyRecipes.Models
{
    public class Recipe
    {
        
        public int RecipeId { get; set; }

        [Required(ErrorMessage ="Please enter a recipe name")]
        public string RecipeName { get; set; }


        [Required(ErrorMessage = "Please enter Ingredients")]
        public string Ingredients { get; set; }

        [Required(ErrorMessage = "Please select a chef")]
        public int ChefId { get; set; }

        public int Category { get; set; }

        [Required(ErrorMessage = "Please enter preptime")]
        public string RecipePrepTime { get; set; }

        [Required(ErrorMessage = "Please enter a description")]
        public string Description { get; set; }
    }
}
