﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EasyRecipes.Models;

namespace EasyRecipes.Controllers
{
    public class RecipeController : Controller
    {
        private IRecipeRepository repository;

        private IChefRepository chefRepository;

        public RecipeController(IRecipeRepository repo, IChefRepository chefRepo)
        {
            repository = repo;
            chefRepository = chefRepo;
        }
        public ViewResult Index()
        {
            return View();
        }
        public ViewResult List()
        {
            ViewBag.Chefs = chefRepository.Chefs;
            return View(repository.FoodRec);
        }


        [HttpGet]
        public ViewResult AddRecipeForm()
        {
            ViewBag.Chefs = chefRepository.Chefs;
            return View();
        }

        [HttpPost]
        public ViewResult AddRecipeForm(Recipe brRecipeForm)
        {
            //repository.FoodRec
            return View("Index");
        }
        public ViewResult ViewRecipe(string PN)
        {
            Recipe recipe = repository.FoodRec.First(s => s.RecipeName == PN);
            ViewBag.Chef = chefRepository.Chefs.First(s => s.ChefId == recipe.ChefId);
            return View(recipe);
        }

        public ViewResult Review()
        {
            return View();
        }

        public ActionResult AdminArea()
        {
            return RedirectToAction("List", "Admin");
        }

        public ViewResult ChefDisplay()
        {
  
            return View(chefRepository.Chefs);
        }

        public ViewResult ChefView(string CF)
        {
            Chef chef = chefRepository.Chefs.First(s => s.ChefName == CF);
       
            return View(chef);
        }

    }

}
