﻿using EasyRecipes.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyRecipes.Controllers
{
    [Authorize]
    public class AdminChefController:Controller
    {
        private IChefRepository chefRepository;

        public AdminChefController(IChefRepository chefRepo)
        {
            chefRepository = chefRepo;
        }
        public ViewResult List()
        {
            return View(chefRepository.Chefs);
        }

        [HttpGet]
        public ViewResult Edit(int chefId)
        {            
            return View(chefRepository.Chefs.FirstOrDefault(r => r.ChefId == chefId));            
        }

        [HttpPost]
        public IActionResult Edit(Chef chef)
        {

            if (ModelState.IsValid)
            {
                chefRepository.SaveChef(chef);
                TempData["message"] = $"{chef.ChefName} has been updated";
                return RedirectToAction("List");
            }
            else
            {
                return View(chef);
            }
        }

        public ViewResult Create()
        {
            return View("Edit", new Chef());
        }

 
        [HttpPost]
        public IActionResult Delete(int chefId)
        {

            Chef deletedChef = chefRepository.DeleteChef(chefId);
            if (deletedChef != null)
            {
                TempData["message"] = $"{deletedChef.ChefName} was deleted!";
            }
            return RedirectToAction("List");
        }

    }
}
