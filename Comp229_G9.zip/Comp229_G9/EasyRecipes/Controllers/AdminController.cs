﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using EasyRecipes.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyRecipes.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {

        private IRecipeRepository repository;
        private IChefRepository chefRepository;

        public AdminController(IRecipeRepository repo, IChefRepository chefRepo)
        {
            repository = repo;
            chefRepository = chefRepo;
        }
        public ViewResult List()
        {
            ViewBag.ChefsAdmin = chefRepository.Chefs;
            return View(repository.FoodRec);
        }

        [HttpGet]
        public ViewResult Edit(int recipeId)
        {
            ViewBag.ChefsAdmin = chefRepository.Chefs;
            return View(repository.FoodRec.FirstOrDefault(r => r.RecipeId == recipeId));

        }

        [HttpPost]
        public IActionResult Edit(Recipe recipe)
        {
            if (ModelState.IsValid)
            {
                repository.SaveRecipe(recipe);
                TempData["message"] = $"{recipe.RecipeName} has been saved";
                return RedirectToAction("List");
            }
            else
            {
                return View(recipe);
            }
        }
        public ViewResult Create()
        {
            ViewBag.ChefsAdmin = chefRepository.Chefs;
            return View("Edit", new Recipe());
        } 


        [HttpPost]
        public IActionResult Delete(int recipeId)
        {

            Recipe deletedRecipe = repository.DeleteRecipe(recipeId);
            if (deletedRecipe != null)
            {
                TempData["message"] = $"{deletedRecipe.RecipeName} was deleted!";
            }
            return RedirectToAction("List");
        }
    }
}
 